import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function UrlShortenerDashboard({ user }) {
  const [urls, setUrls] = useState([]);
  const [stats, setStats] = useState({ total_urls: 0, total_clicks: 0 });
  const [longUrl, setLongUrl] = useState('');
  const [customSlug, setCustomSlug] = useState('');
  const [msg, setMsg] = useState(null);
  const [clickData, setClickData] = useState(null);

  const API = 'http://localhost:5000/api/urls';
  const toast = (m, ok = true) => setMsg({ text: m, ok });

  const deriveTitleFromUrl = (url) => {
    try {
      const slug = new URL(url).pathname.split('/').filter(Boolean).pop() || '';
      return decodeURIComponent(slug.replace(/[-_]/g, ' ')).slice(0, 120);
    } catch {
      return '';
    }
  };

  // ✅ FIXED: Group short URLs by news title or some consistent logic
  const groupByNewsTitle = (rows) => {
    const map = {};
    rows.forEach((r) => {
      const key = r.news_title || r.long_url;
      if (!map[key]) {
        map[key] = {
          base: key,
          originalUrl: r.long_url,
          newsTitle: r.news_title,
          date: r.created_at,
          clicks: 0,
          username: r.username,
          platforms: {}
        };
      }
      map[key].platforms[r.platform] = r.short_url;
      map[key].clicks += r.clicks;
    });
    return Object.values(map);
  };

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [u, s] = await Promise.all([
          axios.get(`${API}/all`),
          axios.get(`${API}/stats`)
        ]);
        setUrls(groupByNewsTitle(u.data));
        setStats(s.data);
      } catch {
        toast('Could not load data', false);
      }
    };
    fetchAll();
  }, []);

  const handleShorten = async () => {
    if (!longUrl.trim()) {
      toast('Enter the news URL', false);
      return;
    }

    try {
      await axios.post(`${API}/shorten`, {
        long_url: longUrl,
        news_title: deriveTitleFromUrl(longUrl),
        custom_short_url: customSlug || undefined,
        user_id: user?.id || 1,
      });

      toast('Short URLs created!');
      setLongUrl('');
      setCustomSlug('');

      const [u, s] = await Promise.all([
        axios.get(`${API}/all`),
        axios.get(`${API}/stats`)
      ]);
      setUrls(groupByNewsTitle(u.data));
      setStats(s.data);
    } catch (e) {
      toast(e.response?.data?.message || 'Shortening failed', false);
    }
  };

  const handlePluginClick = async (plugin) => {
    if (plugin === 'Random ShortURLs Settings') {
      const len = +prompt('Enter short-URL length (6 or 7):', '6');
      if ([6, 7].includes(len)) {
        try {
          await axios.post(`${API}/set-length`, { length: len });
          toast(`Length set to ${len}`);
        } catch {
          toast('Could not update length', false);
        }
      }
    } else if (plugin === 'Fallback URL Plugin Config') {
      alert('Invalid links automatically redirect to /login.');
    } else {
      alert(`${plugin} clicked`);
    }
  };

  const handleStatsClick = async (newsTitle) => {
    try {
      const res = await axios.get(`${API}/platform-clicks/${newsTitle}`);
      setClickData({ base: newsTitle, data: res.data });
    } catch {
      toast('Could not load platform-wise clicks', false);
    }
  };

  return (
    <div className="container mt-3" style={{ maxWidth: 1100, fontSize: '0.9rem' }}>
      {msg && (
        <div className={`alert alert-${msg.ok ? 'success' : 'danger'} py-2`} onClick={() => setMsg(null)} style={{ cursor: 'pointer' }}>
          {msg.text}
        </div>
      )}

      <div className="card shadow-sm p-3">
        <div className="d-flex justify-content-end mb-2">
          <div className="text-end">
            <h4 className="text-primary mb-0" style={{ fontSize: '1.25rem' }}>YOURLS: Your Own URL Shortener</h4>
            <div className="fw-semibold" style={{ fontSize: '1rem' }}>ಉದಯವಾಣಿ</div>
          </div>
        </div>

        <p className="mb-1">
          Hello <strong>{user?.username || 'udayavani'}</strong> (
          <button onClick={() => window.location.reload()} className="btn btn-link p-0" style={{ fontSize: '0.9rem' }}>Logout</button>) |{' '}
          <button onClick={() => alert('Change-password functionality')} className="btn btn-link p-0" style={{ fontSize: '0.9rem' }}>Change password</button>
        </p>

        <p className="fw-bold mb-1 mt-2">Admin Interface</p>
        <p className="fw-bold mb-1">Tools:</p>
        <p className="fw-bold mb-1">Manage Plugins</p>
        <ul className="ms-3 mb-2">
          {['Change Password', 'Fallback URL Plugin Config', 'Random ShortURLs Settings', 'Time Zone Configuration'].map(p => (
            <li key={p}>
              <button onClick={() => handlePluginClick(p)} className="btn btn-link p-0 text-primary">{p}</button>
            </li>
          ))}
        </ul>
        <div className="ms-3 mb-3">
          <button onClick={() => alert('Help clicked')} className="btn btn-link p-0 text-primary">Help</button>
        </div>

        <p>Display <strong>{Math.min(urls.length, 15)}</strong> of <strong>{stats.total_urls}</strong>.</p>
        <p>Overall, tracking <strong>{stats.total_urls}</strong> links, <strong>{stats.total_clicks}</strong> clicks!</p>

        <div className="p-2 mb-3 rounded" style={{ background: '#e6f2ff' }}>
          <div className="row g-2 align-items-center">
            <div className="col-md-1 fw-bold">News URL:</div>
            <div className="col-md-5">
              <input value={longUrl} onChange={e => setLongUrl(e.target.value)} className="form-control form-control-sm" placeholder="https://" />
            </div>
            <div className="col-md-1 fw-bold">Optional:</div>
            <div className="col-md-3">
              <input value={customSlug} onChange={e => setCustomSlug(e.target.value)} className="form-control form-control-sm" placeholder="Enter custom short URL" />
            </div>
            <div className="col-md-2 mt-2 mt-1 text-end">
              <button onClick={handleShorten} className="btn btn-sm btn-primary">Shorten URL</button>
            </div>
          </div>
        </div>

        <div className="table-responsive">
          <table className="table table-bordered table-hover table-sm">
            <thead className="table-primary text-center align-middle">
              <tr>
                <th colSpan="4">Short URL</th>
                <th rowSpan="2">Original URL</th>
                <th rowSpan="2">Date</th>
                <th rowSpan="2">Clicks</th>
                <th rowSpan="2">Username</th>
                <th rowSpan="2">Actions</th>
              </tr>
              <tr>
                <th>Facebook</th><th>Twitter</th><th>Telegram</th><th>Whatsapp</th>
              </tr>
            </thead>
            <tbody>
              {urls.map(row => (
                <tr key={row.base}>
                  {['facebook', 'twitter', 'telegram', 'whatsapp'].map(p => (
                    <td key={p}>
                      {row.platforms[p]
                        ? <a href={`http://localhost:5000/${row.platforms[p]}`} className="text-primary" target="_blank" rel="noopener noreferrer">
                            {row.platforms[p]}
                          </a>
                        : <span className="text-muted">-</span>}
                    </td>
                  ))}
                  <td className="text-truncate" style={{ maxWidth: 250 }} title={row.originalUrl}>
                    <a href={row.originalUrl} target="_blank" rel="noopener noreferrer">{row.originalUrl}</a>
                    {row.newsTitle && <div className="text-muted small mt-1">{row.newsTitle}</div>}
                  </td>
                  <td>{new Date(row.date).toLocaleString()}</td>
                  <td>{row.clicks}</td>
                  <td>{row.username}</td>
                  <td className="text-center">
                    <button className="btn btn-sm btn-outline-primary me-1" title="Stats" onClick={() => handleStatsClick(row.base)}>📊</button>
                    <button className="btn btn-sm btn-outline-secondary me-1" title="Edit">✏️</button>
                    <button className="btn btn-sm btn-outline-danger" title="Delete">🗑️</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {clickData && (
        <div className="position-fixed top-0 start-0 w-100 h-100 bg-dark bg-opacity-50 d-flex align-items-center justify-content-center" style={{ zIndex: 1050 }}>
          <div className="bg-white p-4 rounded shadow" style={{ minWidth: 300 }}>
            <h5 className="mb-3">Clicks for {clickData.base}</h5>
            <ul className="list-unstyled">
              {['facebook', 'twitter', 'telegram', 'whatsapp'].map(p => (
                <li key={p} className="mb-1">
                  <strong>{p}:</strong> {clickData.data[p] || 0}
                </li>
              ))}
            </ul>
            <button onClick={() => setClickData(null)} className="btn btn-sm btn-secondary mt-2">Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
